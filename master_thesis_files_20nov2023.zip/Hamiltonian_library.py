import numpy as np
import qutip as qt
import scipy as sp
from scipy import linalg
import matplotlib
import matplotlib.pylab as plt
import krotov
import os.path
import random
from matplotlib import rc
from cycler import cycler
import time
import pandas as pd
from Hamiltonian_library import *
from config import *

class HamiltonianClass():
    """
    Old Hamiltonian with no momentum transfer functionality
    """
    def  set_Hamiltonian_noCMT(self,args):


        tensor1 = qt.tensor(qt.qeye(self.N_points),qt.Qobj([[0,0],[0,1]]))
        tensorn = qt.tensor(qt.num(self.N_points,offset=1),qt.Qobj([[0,0],[0,1]]))
        tensord = qt.tensor(qt.qeye(self.N_points),qt.sigmax())
        vel_squared = qt.Qobj(self.velocity_bins)*qt.Qobj(self.velocity_bins).dag()
        

        # H0 = hbar*(laser.detuning+laser.direction*self.velocity_bins[0]/c*(laser.omega0+laser.detuning))*self.tensor_e
        # Hv0 = hbar * self.dv * (laser.omega0 + laser.detuning) * laser.direction/c * self.tensor_enum
        # H_v_chirp = hbar*laser.chirp*laser.direction*self.dv/c*self.tensor_enum
        # H_chirp = hbar * laser.chirp*(1+laser.direction*self.velocity_bins[0]/c)*self.tensor_e
        # H_transition = 0.5*hbar*tensord

        # H = [H0,Hv0,[H_chirp+H_v_chirp,laser.tlist-laser.tlist_centre],[H_transition,laser.rabi]]

        H = []
        H.append(omega0*self.tensor_e - (self.tensor_qeye+self.tensor_vel/c)*args["omega_L0"]*self.tensor_e)
        H.append([(self.tensor_qeye+self.tensor_vel/c)*self.tensor_e,args["chirp"]])
        H.append([0.5*hbar*tensord,args["rabi"]])
        self.H = H
        #opts = qt.Options(store_states=True)
        #result = qt.mesolve(H, self.states,laser.tlist, options = opts)
        #self.states = result.states[-1]
            

    """
    Hamiltonian including momentum transfer
    """
    def set_Hamiltonian_MT(self,args):   
        omega_recoil = 0#0.5*hbar*hbar_eV*self.wavenumber_value**2/(self.m/c**2) # 1/ps   
        # re-dub omega0 -> omega_L0 where appropriate, for the 
        
        H = []
        H.append(-hbar*args["wavevector"]*args["omega_L0"]*self.tensor_vel/c*self.tensor_e
                    +hbar*(self.tensor_enum**2*omega_recoil*(self.tensor_g+self.tensor_e)
                    +hbar*(omega0 - args["omega_L0"])*self.tensor_e))
        
        H.append([hbar*self.tensor_e
                  +hbar*args["wavevector"]*self.tensor_vel/c*self.tensor_e,args["chirp"]]) # chirp terms
        H.append([-hbar*(0.5*self.tensor_ge +0.5*self.tensor_eg),args["rabi"]*args["selector1"]]) # time-dependent coupling terms               
        H.append([-hbar*(0.5*self.tensor_ge2 +0.5*self.tensor_eg2),args["rabi"]*args["selector2"]]) # time-dependent coupling terms               
        
        # DONT DELETE IN CASE I NEED TO CHANGE BACK TO THIS.
        # Used before I realised I can't solve for 1 train of pulses. It has to make a new sovler object for each pulse instead...
        #H.append([-hbar*omega0*self.tensor_vel/c*self.tensor_e,args["wavevector"]]) # velocity term
        #H.append([hbar*self.tensor_vel/c*self.tensor_e,args["chirp"]*args["wavevector"]]) # velocity term

        self.H = H


    # def set_Hamiltonian_MT_general(self,rabi_frequency,phi,**kwargs):          
    #     # phi is the derivative of the instantaneous laser frequency with v=0
    #     H = []
    #     H.append(hbar*omega0*self.tensor_e)
    #     H.append([-hbar*(self.tensor_qeye+self.tensor_vel/c)*self.tensor_e,phi])
    #     H.append([hbar*(self.tensor_ge +self.tensor_eg),rabi_frequency*kwargs["selector1"]]) # time-dependent coupling terms               
    #     H.append([hbar*(self.tensor_ge2 +self.tensor_eg2),rabi_frequency*kwargs["selector2"]]) # time-dependent coupling terms               

    #     self.H = H

    def set_Hamiltonian_MT_general_laser(self,laser):          
        H = []
        H.append(hbar*omega0*self.tensor_e-(self.tensor_qeye+self.tensor_vel/c)*self.tensor_e*laser.omega_L0)
        H.append([hbar*(self.tensor_qeye+self.tensor_vel/c)*self.tensor_e,laser.detuning])
        H.append([-hbar*(self.tensor_ge +self.tensor_eg),laser.envelope*laser.selector1]) # time-dependent coupling terms               
        H.append([-hbar*(self.tensor_ge2 +self.tensor_eg2),laser.envelope*laser.selector2]) # time-dependent coupling terms               
        
        
        self.H = H

    def set_Hamiltonian_noMT_general_laser(self,laser):    
        tensord = qt.tensor(qt.qeye(self.N_points),qt.sigmax())
        
        H = []
        H.append(hbar*omega0*self.tensor_e-(self.tensor_qeye+laser.unit_wavevector*self.tensor_vel/c)*self.tensor_e*laser.omega_L0)
        H.append([-hbar*(self.tensor_qeye+laser.unit_wavevector*self.tensor_vel/c)*self.tensor_e,laser.detuning])
        H.append([-hbar*(tensord),laser.envelope]) # time-dependent coupling terms               

        self.H = H



    # for each new dissipation channel do:
    # 1. Expand the internal state arrays
    # 2. Define the coupling strength between the environment and system, along with the jump operator, and add them onto the current list of collapse operators
    # 3. Add new expectation operator to the current list of e_ops
    def include_SE_simple(self,laser,flag_SE_simple=False):
        if flag_SE_simple:
            # dissipation is between already-existing states. So no need to expand dimensions.
            oper_SE = qt.projection(self.internal_dims,0,1)
            rate_SE_simple = 1 # THz
            coupling_strength_SE = np.sqrt(rate_SE_simple)
            self.c_ops += [coupling_strength_SE*qt.tensor(qt.qeye(self.N_points),oper_SE)]
    
    def include_SE_distributive(self,flag_SE_distributive=False,rate_SE=None):
        if flag_SE_distributive:
            oper_SE = qt.projection(self.internal_dims,0,1)
            if rate_SE ==None:
                rate_SE = self.rate_SE # THz
            for n in range(1,self.N_points-1):
                self.c_ops.append(np.sqrt(rate_SE*0.6)*qt.tensor(self.kets_vel[n]*self.kets_vel[n].dag(),oper_SE))
                self.c_ops.append(np.sqrt(rate_SE*0.2)*qt.tensor(self.kets_vel[n+1]*self.kets_vel[n].dag(),oper_SE))
                self.c_ops.append(np.sqrt(rate_SE*0.2)*qt.tensor(self.kets_vel[n-1]*self.kets_vel[n].dag(),oper_SE))
                


    def include_photoionisation_prev(self, laser, flag_photoionisation=False):
        if flag_photoionisation:
            self.internal_dims +=1 
            self.states_dict["ph."] = self.internal_dims
            oper_photoionisation = qt.projection(self.internal_dims,self.internal_dims-1,1)
            coupling_constant = photoionisation_cross_section*eps0*c*hbar_eV/(2*omega0*Debye**2)
            coupling_strength_photoionisation = np.sqrt(coupling_constant*laser.envelope**2)

            self.add_new_dissipative_state(oper_photoionisation,coupling_strength_photoionisation)
            self.proj_photoionisation = qt.ket2dm(qt.basis(self.internal_dims,self.internal_dims-1))
            self.e_ops +=   [qt.tensor(self.kets_vel[n]*self.kets_vel[n].dag(),self.proj_photoionisation) for n in range(self.N_points)]
            self.idx_e_ops["ph."] = np.arange(self.order*self.N_points,(self.order+1)*self.N_points)

            self.order +=1


    def include_annihilation_prev(self,flag_annihilation=False):
        if flag_annihilation:
            self.internal_dims +=1
            self.states_dict["ann."] = self.internal_dims
            rate_annihilation = 1/142e3 # ps CHANGE
            coupling_strength_annihilation = np.sqrt(rate_annihilation)
            #oper_annhilation = qt.projection(self.internal_dims,self.internal_dims-1,0)
            #self.dissipative_couplings["ann."] = rate_
            self.add_new_dissipative_state(oper_annhilation,coupling_strength_annihilation)
            self.proj_annihilation = qt.ket2dm(qt.basis(self.internal_dims,self.internal_dims-1))
            self.e_ops += [qt.tensor(self.kets_vel[n]*self.kets_vel[n].dag(),self.proj_annihilation) for n in range(self.N_points)]
            self.idx_e_ops["ann."] = np.arange(self.order*self.N_points,(self.order+1)*self.N_points)            
            self.order +=1

    def include_photoionisation(self, laser, flag_photoionisation=False):
        if flag_photoionisation:
            self.internal_dims +=1 
            self.states_dict["ph."] = self.internal_dims-1
            #oper_photoionisation = qt.projection(self.internal_dims,self.internal_dims-1,1)
            self.dissipative_couplings["ph."] = self.states_dict["2P"]
            coupling_constant = photoionisation_cross_section*eps0*c*hbar_eV/(2*omega0*Debye**2)
            coupling_strength_photoionisation = np.sqrt(coupling_constant*laser.envelope**2)
            self.dissipative_coupling_strengths["ph."] = coupling_strength_photoionisation
            # self.add_new_dissipative_state(oper_photoionisation,coupling_strength_photoionisation)
            # self.proj_photoionisation = qt.ket2dm(qt.basis(self.internal_dims,self.internal_dims-1))
            # self.e_ops +=   [qt.tensor(self.kets_vel[n]*self.kets_vel[n].dag(),self.proj_photoionisation) for n in range(self.N_points)]
            # self.idx_e_ops["ph."] = np.arange(self.order*self.N_points,(self.order+1)*self.N_points)

            # self.order +=1


    def include_annihilation(self,flag_annihilation=False,ann_rate=None):
        if flag_annihilation:
            self.internal_dims +=1
            self.states_dict["ann."] = self.internal_dims-1
            self.dissipative_couplings["ann."] = self.states_dict["1S"]
            if ann_rate == None:
                ann_rate = 1/142e3 # ps 
            coupling_strength_annihilation = np.sqrt(ann_rate)
            self.dissipative_coupling_strengths["ann."] = coupling_strength_annihilation
            
            #oper_annhilation = qt.projection(self.internal_dims,seself.states_dict["1S"] = 0; self.states_dict["2P"] = 1lf.internal_dims-1,0)
            
            # self.add_new_dissipative_state(oper_annhilation,coupling_strength_annihilation)
            # self.proj_annihilation = qt.ket2dm(qt.basis(self.internal_dims,self.internal_dims-1))
            # self.e_ops += [qt.tensor(self.kets_vel[n]*self.kets_vel[n].dag(),self.proj_annihilation) for n in range(self.N_points)]
            # self.idx_e_ops["ann."] = np.arange(self.order*self.N_points,(self.order+1)*self.N_points)            
            # self.order +=1

    """
    add a new liouville operator to the list of current ones, given a liouville operator and corresponding coupling strength.
    The coupling strength can be a single value, or a function over time given as a list
    """
    def add_new_dissipative_states(self):
        states_dict = self.states_dict.copy()
        del states_dict["1S"]
        del states_dict["2P"]

        for key in states_dict:
            
            new_op = []
            coupling_strength = self.dissipative_coupling_strengths[key]
            jump_operator = qt.projection(self.internal_dims,self.states_dict[key],self.dissipative_couplings[key])
            if type(coupling_strength) == type([]) or type(coupling_strength) == type(np.asarray([])):
                for ket in self.kets_vel:
                    new_op.append(qt.tensor(ket*ket.dag(),jump_operator))
                self.c_ops.append([sum(new_op),coupling_strength])
            else:
                try:
                    new_op = [coupling_strength*qt.tensor(ket*ket.dag(),jump_operator) for ket in self.kets_vel]
                    self.c_ops.append(new_op)
                except ValueError:
                    print("Environment coupling strength cannot be typecast to float") 

            proj = qt.ket2dm(qt.basis(self.internal_dims,self.states_dict[key]))
            self.e_ops += [qt.tensor(self.kets_vel[n]*self.kets_vel[n].dag(),proj) for n in range(self.N_points)]
            self.idx_e_ops[key] = np.arange(self.order*self.N_points,(self.order+1)*self.N_points)            
            self.order +=1


    """
    add a new liouville operator to the list of current ones, given a liouville operator and corresponding coupling strength.
    The coupling strength can be a single value, or a function over time given as a list
    """
    def add_new_dissipative_state(self,jump_operator,coupling_strength,):
        new_op = []
        if type(coupling_strength) == type([]) or type(coupling_strength) == type(np.asarray([])):
            for ket in self.kets_vel:
                new_op.append(qt.tensor(ket*ket.dag(),jump_operator))
            self.c_ops.append([sum(new_op),coupling_strength])
            print("passed_try")
        else:
            try:
                print("passed_else")
                new_op = [coupling_strength*qt.tensor(ket*ket.dag(),jump_operator) for ket in self.kets_vel]
                self.c_ops.append(new_op)
            except ValueError:
                print("Environment coupling strength cannot be typecast to float") 


    def create_velocity_space(self):
        self.qobj_vel = qt.Qobj(np.diag(self.velocity_bins))
        self.qobj_n_prev = qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n+1].dag() for n in range(1,self.N_points-1)]),axis=0))
        self.qobj_n_next = qt.Qobj(np.sum(np.asarray([self.kets_vel[n+1]*self.kets_vel[n].dag() for n in range(1,self.N_points-1)]),axis=0))
    

    def create_internal_state_space(self):
        self.proj_1S = qt.ket2dm(qt.basis(self.internal_dims,0))
        self.e_ops +=  [qt.tensor(self.kets_vel[n]*self.kets_vel[n].dag(),self.proj_1S) for n in range(self.N_points)]
        self.idx_e_ops["1S"] = np.arange(self.order*self.N_points,(self.order+1)*self.N_points)
        self.order +=1
        
        self.proj_2P = qt.ket2dm(qt.basis(self.internal_dims,1))
        self.e_ops +=  [qt.tensor(self.kets_vel[n]*self.kets_vel[n].dag(),self.proj_2P) for n in range(self.N_points)]
        self.idx_e_ops["2P"] = np.arange(self.order*self.N_points,(self.order+1)*self.N_points)
        self.order +=1
        
        self.proj_1S_to_2P = qt.projection(self.internal_dims,1,0)
        self.proj_2P_to_1S = qt.projection(self.internal_dims,0,1)


    def create_composite(self,laser=None,SE_rate=None,ann_rate=None):
        self.c_ops = []
        self.e_ops = []
        self.internal_dims = 2
        self.idx_e_ops = dict()
        self.states_dict = dict() # dissipative states names
        self.states_dict["1S"] = 0; self.states_dict["2P"] = 1;
        self.dissipative_coupling_strengths = dict() # dissipative state coupling srengths
        self.dissipative_couplings = dict()
        self.order = 0
        self.create_velocity_space()

        # make sure dissipation that changes the number of internal states comes first
        self.include_annihilation(self.flag_annihilation,ann_rate)
        self.include_photoionisation(laser,self.flag_photoionisation)
        self.add_new_dissipative_states()
        # need to change code so that the internal dimensions are first defined, and THEN the states themselves are defined. 
        # because right now, annihilation creates a 3-dim proj vector, when it should be 4-dim when both annilhation and photoionisation are included in the simulations
        # create a dict containing key:value pairs indicating which dimension corresponds to which state, then create states based on that
        # # if I was smart, I would create an "internal state" objectju

        self.include_SE_simple(laser,self.flag_SE_simple)
        self.include_SE_distributive(self.flag_SE_distributive,SE_rate)
        
        
        self.create_internal_state_space()
        self.tensor_qeye = qt.tensor(qt.qeye(self.N_points),qt.qeye(self.internal_dims))
        self.tensor_enum = qt.tensor(qt.num(self.N_points,offset=-self.N_points//2+1),qt.qeye(self.internal_dims)) # enumerated tensor
        self.tensor_vel = qt.tensor(self.qobj_vel,qt.qeye(self.internal_dims))  
        
        self.tensor_g = qt.tensor(qt.qeye(self.N_points),self.proj_1S) # ground 
        self.tensor_e = qt.tensor(qt.qeye(self.N_points),self.proj_2P) # excited
        self.tensor_eg = qt.tensor(self.qobj_n_prev,self.proj_1S_to_2P) 
        self.tensor_ge = qt.tensor(self.qobj_n_next,self.proj_2P_to_1S) 
        self.tensor_eg2 = qt.tensor(self.qobj_n_prev,self.proj_2P_to_1S)
        self.tensor_ge2 = qt.tensor(self.qobj_n_next,self.proj_1S_to_2P)

    def evolve(self):
        pass



"""
NOT USED. LEGACY CODE

    def set_Hamiltonian_Optimization(self,guess_phase,guess_envelope,detuning):        
        omega_recoil = 0
        tensor_vel = qt.tensor(qt.Qobj(np.diag(self.velocity_bins)),qt.qeye(2))     
        tensor_num = qt.tensor(qt.num(self.N_points,offset=-self.N_points//2+1),qt.qeye(2)) # enumerated tensor
        tensor_g = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[1,0],[0,0]])) # ground 
        tensor_e = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[0,0],[0,1]])) # excited
        tensor_eg = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n+1].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,0],[1,0]])) # excited to ground
        tensor_ge = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n+1]*self.kets_vel[n].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,1],[0,0]])) # ground to excited
        
        H = []
        H.append(hbar*(tensor_num**2*omega_recoil*(tensor_g+tensor_e))-hbar*(self.omega0-(self.omega0+detuning)*(1+tensor_vel/c))*tensor_e)
        H.append([hbar*(1+tensor_vel/c)*tensor_e,guess_phase]) # chirp terms
        H.append([-hbar*(0.5*tensor_ge +0.5*tensor_eg),guess_envelope])
        
        self.H = H




    # Sum of two pulses with two different detunings
    def set_Hamiltonian_notched_MT(self):

        self.init_pulse_cycle()
        
        # if you have coupling between  states more than 1 bin from each other, should probably find a way to make this non-zero...
        omega_recoil = 0#0.5*hbar*hbar_eV*self.wavenumber_value**2/(self.m/c**2) # 1/ps   
        
        tensor_vel = qt.tensor(qt.Qobj(np.diag(self.velocity_bins)),qt.qeye(2))     
        tensor_num = qt.tensor(qt.num(self.N_points,offset=-self.N_points//2+1),qt.qeye(2)) # enumerated tensor

        tensor_g = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[1,0],[0,0]])) # ground 
        tensor_e = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[0,0],[0,1]])) # excited
        
        tensor_eg = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n+1].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,0],[1,0]])) # excited to ground
        tensor_ge = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n+1]*self.kets_vel[n].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,1],[0,0]])) # ground to excited
        
        tensor_eg2 = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n+1]*self.kets_vel[n].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,0],[1,0]])) # excited to ground
        tensor_ge2 = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n+1].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,1],[0,0]])) # ground to excited

        H = []
        H.append(hbar*(tensor_num**2*omega_recoil*(tensor_g+tensor_e))) # kinetic energy
        H.append([hbar*tensor_e,self.chirp]) # chirp terms
        H.append([-hbar*np.pi/2*tensor_e,self.notch_function])
        H.append([-hbar*omega0*tensor_vel/c*tensor_e,self.wavevector]) # velocity term
        H.append([hbar*tensor_vel/c*tensor_e,self.chirp*self.wavevector]) # velocity term
        
        H.append([-hbar*(0.5*tensor_ge +0.5*tensor_eg),self.rabi*self.func1]) # time-dependent coupling terms               
        H.append([-hbar*(0.5*tensor_ge2 +0.5*tensor_eg2),self.rabi*self.func2]) # time-dependent coupling terms               

        self.H = H
        
    # sin beating definition
    def set_Hamiltonian_notched_MT2(self):       
        omega_recoil = 0#0.5*hbar*hbar_eV*self.wavenumber_value**2/(self.m/c**2) # 1/ps   
        
        tensor_vel = qt.tensor(qt.Qobj(np.diag(self.velocity_bins)),qt.qeye(2))     
        tensor_num = qt.tensor(qt.num(self.N_points,offset=-self.N_points//2+1),qt.qeye(2)) # enumerated tensor

        tensor_g = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[1,0],[0,0]])) # ground 
        tensor_e = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[0,0],[0,1]])) # excited
        
        tensor_eg = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n+1].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,0],[1,0]])) # excited to ground
        tensor_ge = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n+1]*self.kets_vel[n].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,1],[0,0]])) # ground to excited
        
        tensor_eg2 = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n+1]*self.kets_vel[n].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,0],[1,0]])) # excited to ground
        tensor_ge2 = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n+1].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,1],[0,0]])) # ground to excited
        H = []
        H.append(hbar*(tensor_num**2*omega_recoil*(tensor_g+tensor_e))) # kinetic energy
        H.append([hbar*tensor_e,self.chirp]) # chirp terms
        H.append([-hbar*omega0*tensor_vel/c*tensor_e,self.wavevector]) # velocity term
        H.append([hbar*tensor_vel/c*tensor_e,self.chirp*self.wavevector]) # velocity term
        
        H.append([-hbar*(tensor_ge +tensor_eg),self.rabi_beating*self.func1]) # time-dependent coupling terms               
        H.append([-hbar*(tensor_ge2 +tensor_eg2),self.rabi_beating*self.func2]) # time-dependent coupling terms               

        self.H = self.H + H

    # beating with arctan definition
    def set_Hamiltonian_notched_MT3(self):        
        omega_recoil = 0#0.5*hbar*hbar_eV*self.wavenumber_value**2/(self.m/c**2) # 1/ps   
        
        tensor_vel = qt.tensor(qt.Qobj(np.diag(self.velocity_bins)),qt.qeye(2))     
        tensor_num = qt.tensor(qt.num(self.N_points,offset=-self.N_points//2+1),qt.qeye(2)) # enumerated tensor

        tensor_g = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[1,0],[0,0]])) # ground 
        tensor_e = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[0,0],[0,1]])) # excited
        
        tensor_eg = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n+1].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,0],[1,0]])) # excited to ground
        tensor_ge = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n+1]*self.kets_vel[n].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,1],[0,0]])) # ground to excited

        tensor_eg2 = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n+1]*self.kets_vel[n].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,0],[1,0]])) # excited to ground
        tensor_ge2 = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n+1].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,1],[0,0]])) # ground to excited
        H = []
        H.append(hbar*(tensor_num**2*omega_recoil*(tensor_g+tensor_e))) # kinetic energy
        H.append([hbar*tensor_e,self.chirp]) # chirp terms
        H.append([-hbar*omega0*tensor_vel/c*tensor_e,self.wavevector]) # velocity term
        H.append([hbar*tensor_vel/c*tensor_e,self.chirp*self.wavevector]) # velocity term
        
        H.append([-hbar*(tensor_ge +tensor_eg),self.rabi_beating2*self.func1]) # time-dependent coupling terms               
        H.append([-hbar*(tensor_ge2 +tensor_eg2),self.rabi_beating2*self.func2]) # time-dependent coupling terms               

        self.H = H
    

    def set_Hamiltonian_notched_MT4(self,args):        
        omega_recoil = 0#0.5*hbar*hbar_eV*self.wavenumber_value**2/(self.m/c**2) # 1/ps   
        
        H = []
        H.append(hbar*(self.tensor_num**2*omega_recoil*(self.tensor_g+self.tensor_e))) # kinetic energy
        H.append([hbar*self.tensor_e,args["chirp"]]) # chirp terms
        H.append([-hbar*omega0*self.tensor_vel/c*self.tensor_e,args["wavevector"]]) # velocity term
        H.append([hbar*self.tensor_vel/c*self.tensor_e,args["chirp"]*args["wavevector"]]) # velocity term
        
        H.append([-hbar*(self.tensor_ge +self.tensor_eg),args["beating"]*args["selector1"]]) # time-dependent coupling terms               
        H.append([-hbar*(self.tensor_ge2 +self.tensor_eg2),args["beating"]*args["selector2"]]) # time-dependent coupling terms               

        self.H = H


# UNUSED, originally meant to add a single extra state for photoionisation, but this is not compatible with QuTiP's Hamiltonian formulation
    def addDissipation(self,arr):
        new_arr = np.insert(arr,self.N_points,np.zeros(self.N_points),0)
        new_arr = np.insert(new_arr,self.N_points,0,1)
        return new_arr

    # NOT USED
    def set_Hamiltonian_MT3(self):        
        tensor_vel = qt.tensor(qt.Qobj(np.diag(self.velocity_bins)),qt.qeye(2))     
        tensor_num = qt.tensor(qt.num(self.N_points,offset=-self.N_points//2+1),qt.qeye(2)) # enumerated tensor

        tensor_g = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[1,0],[0,0]])) # ground 
        tensor_e = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[0,0],[0,1]])) # excited
        
        tensor_eg = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n-1].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,0],[1,0]])) # excited to ground
        tensor_ge = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n-1]*self.kets_vel[n].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,1],[0,0]])) # ground to excited
        
        tensor_eg2 = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n+1].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,0],[1,0]])) # excited to ground
        tensor_ge2 = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n+1]*self.kets_vel[n].dag() for n in range(1,self.N_points-1)]),axis=0)),qt.Qobj([[0,1],[0,0]])) # ground to excited

        states = self.states
        for laser in self.laserDict:
            chirp = np.asarray(laser[1].chirp(laser[1].tlist,None))
            wavevector = laser[1].unit_wavevector
            rabi = np.asarray(laser[1].rabi(laser[1].tlist,None))
            
            omega_recoil = 0#0.5*hbar*hbar_eV*laser[1].wavenumber_value**2/(self.m/c**2) # 1/ps
            H = []
            
            H.append(hbar*((tensor_num**2*omega_recoil*(tensor_g+tensor_e)) +(self.omega0-(laser[1].omega0+laser[1].detuning)*(1+tensor_vel/c*wavevector))*tensor_e)) # time-independent
            
            H.append([hbar*(1+tensor_vel/c*wavevector)*tensor_e,chirp]) # chirp terms
            if wavevector == 1:
                H.append([-hbar*(0.5*tensor_ge +0.5*tensor_eg),rabi]) # time-dependent coupling terms               
            else:
                H.append([-hbar*(0.5*tensor_ge2 +0.5*tensor_eg2),rabi]) # time-dependent coupling terms               
            
            opts = qt.Options(store_states=True,nsteps=10000)
            result = qt.mesolve(H, states,laser[1].tlist, options = opts,progress_bar=True)
            
            states = result.states[-1]
            self.saved_states.append(states)
        self.states = states

    # No longer used
    def set_Hamiltonian_MT(self,laserLabel):
        laser = self.laserDict[0][1]

        omega_recoil = 0.5*hbar*hbar_eV*laser.wavenumber_value**2/(self.m/c**2) # 1/ps   
        print(omega_recoil)
        tensor_vel = qt.tensor(qt.Qobj(np.diag(self.velocity_bins)),qt.qeye(2))        
        tensor_num = qt.tensor(qt.num(self.N_points,offset=1),qt.qeye(2)) # enumerated tensor
        tensor_g = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[1,0],[0,0]])) # ground 
        tensor_e = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(self.N_points)]),axis=0)),qt.Qobj([[0,0],[0,1]])) # excited
        tensor_eg = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n+1].dag() for n in range(self.N_points-1)]),axis=0)),qt.Qobj([[0,0],[1,0]])) # excited to ground
        tensor_ge = qt.tensor(qt.Qobj(np.sum(np.asarray([self.kets_vel[n+1]*self.kets_vel[n].dag() for n in range(self.N_points-1)]),axis=0)),qt.Qobj([[0,1],[0,0]])) # ground to excited
        
        
        H = []
        H.append(hbar*(tensor_num**2*omega_recoil*(tensor_g+tensor_e) - self.omega0*tensor_vel/c*tensor_e)) # time-independent
        H.append([hbar*(1+tensor_vel/c)*laser.chirp0,laser.tlist-laser.tlist_centre]) # time-dependent terms
        H.append([hbar*(-0.5*tensor_eg-0.5*tensor_ge),laser.rabi]) # time-dependent coupling terms                

        opts = qt.Options(store_states=True)
        result = qt.mesolve(H, self.states,laser.tlist, options = opts)
        self.states = result.states[-1]


   def add_dimension_to_system(self):
        self.arr_1S = self.add_dimension(self.arr_1S)
        self.arr_2P = self.add_dimension(self.arr_2P)
        self.arr_1S_to_2P = self.add_dimension(self.arr_1S_to_2P)
        self.arr_2P_to_1S = self.add_dimension(self.arr_2P_to_1S)
        self.internal_dims += 1


    def add_dimension(self,arr):
        arr = np.insert(arr,self.internal_dims,0,axis=1)
        arr = np.append(arr,[0]*self.internal_dims,0)
        return arr
    
"""