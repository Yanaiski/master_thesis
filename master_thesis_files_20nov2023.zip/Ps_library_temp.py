import numpy as np
import qutip as qt
import scipy as sp
from scipy import linalg
import matplotlib
import matplotlib.pylab as plt
import krotov
import os.path
import random
from matplotlib import rc
from cycler import cycler
import time
import pandas as pd
import gc

from Hamiltonian_library import *
from config import *


class laser_new:
    def __init__(self,kwargs):
        self.label = kwargs["label"]
        if "isSE" in kwargs:
            self.isSE = True
        else:
            self.isSE = False
        if "tlist" in kwargs:
            self.tlist = kwargs["tlist"]
            self.N_time = self.tlist.size
            self.startTime = self.tlist[0]
            self.endTime = self.tlist[-1]
        else:
            if "scale" in kwargs:
                self.binwidth = 2*np.pi/omega0*kwargs["scale"]
            else:
                self.binwidth = 2*np.pi/omega0*1000

            self.startTime = kwargs["start"] # used in previous versions of code
            self.endTime =  kwargs["end"] #ps 
            self.tcentre = (self.endTime-self.startTime)/2 + self.startTime #ps
            
            self.N_time = int((self.endTime-self.startTime)/self.binwidth)          
            self.tlist = np.linspace(self.startTime,self.endTime,self.N_time)
            self.tlist_centre = np.full(self.N_time,self.tcentre)

        
        self.unit_wavevector = kwargs["unit_wavevector"]
        
        if "order" in kwargs:
            self.order = kwargs["order"] # order of pulse in sequence

        if "omega_L0" in kwargs:
            self.omega_L0 = kwargs["omega_L0"]
        else:
            self.omega_L0 = omega0 # central, non-detuned, laser frequency 

        
        if "envelope" in kwargs:
            self.envelope = kwargs["envelope"]
        else:
            self.pulse_duration = kwargs["pulse_duration"]
            self.rabi0 = kwargs["rabi0"]
            self.envelope = self.rabi0 * np.exp(-4*np.log(2)*(self.tlist-self.tlist_centre)**2/self.pulse_duration**2)
        
        if "detuning" in kwargs:
            self.detuning = kwargs["detuning"]
        else:
            if "higher_order" in kwargs:
                if kwargs["higher_order"] == True:
                    self.chirp = kwargs["chirp"]
                    self.detuning0 = kwargs["detuning0"]    
                    self.jerk = kwargs["jerk"]
                    self.detuning = np.full(self.N_time,self.detuning0) + 0.5*self.chirp*(self.tlist-self.tlist_centre)+self.jerk*(self.tlist-self.tlist_centre)**2
            else:
                self.chirp = kwargs["chirp"]
                self.detuning0 = kwargs["detuning0"]
                self.detuning = np.full(self.N_time,self.detuning0) + 0.5*self.chirp*(self.tlist-self.tlist_centre) 
            
        
        self.selector1 = np.full(self.N_time, 1 if self.unit_wavevector == -1 else 0)
        self.selector2 = np.full(self.N_time, 1 if self.unit_wavevector == 1 else 0)

"""
Class for handling a sequence of pulses
"""
class laser_sequence:
    def __init__(self):
        self.laserDict = dict()
    
    def init_pulse(self,kwargs):
        order = len(self.laserDict)
        kwargs["order"] = order
        laserLabel = kwargs["label"]
        laserObj = laser_new(kwargs)
        self.laserDict[laserLabel] = laserObj

    def pull_sorted_sequence(self):
        return sorted(self.laserDict.items(),key=lambda x:x[1].order)



"""
Various functions for handling states are added here
"""
class data_handler:
    def __init__(self):
        self.figures = dict()
        return None
    
    def save_states_csv(self,obj,path):
        qt.qsave(obj.saved_states,path)
    
    def load_states_csv(self,path):
        return qt.qload(path)

    # for cooling simulations
    def save_results(self,results,directory,sorted_sequence):
        #directory = "./data/cooling/4Trains_2Pulses/"
        for i in range(len(results)):
            laser = sorted_sequence[i][1]
            filename = "{}_{}.csv".format(laser.order,laser.label)
            path = directory+filename
            qt.qsave(results[i],path)
        
    def figure_pulse(self,obj):
        return None
        #self.figures["pulse"] = (fig,axes)
        
    # def get_std(self,result):
    #     #N_pulses = len(obj.saved_states)
        
    #     N_g = np.asarray(result[-1].expect)
        
    #     N_g,N_e,N = obj.get_states(obj.saved_states[j].unit())
    #     std[j] = np.sqrt(np.sum([p_i*v_i**2 for (p_i,v_i) in [(N[i],obj.velocity_bins[i]) for i in range(obj.N_bins)] ]))
    #     return std


    def expect_standard_deviation(self,ket,N_bins):
        #selector_qobj = qt.tensor(qt.qeye(N_bins),qt.Qobj([[1,0],[0,1]])) # select only ground and excited states. Remove ph. states
        #selector_qobj = qt.tensor(qt.qeye(N_bins),qt.Qobj([[1,0,0],[0,1,0],[0,0,0]])) # select only ground and excited states. Remove ph. states
        selector_qobj = qt.tensor(qt.qeye(N_bins),qt.Qobj([[1,0,0,0],[0,1,0,0],[0,0,0,0],[0,0,0,0]])) # select only ground and excited states. Remove ph. states
        vel_ket = ((ket*selector_qobj).ptrace(0)).unit() # partial trace to get only velocity states
        oper_momentum = qt.num(N_bins,offset=-N_bins//2+1)
       
        std = np.sqrt((oper_momentum**2*vel_ket).tr()- (oper_momentum*vel_ket).tr()**2)
        return std
    
    def expect_mean(self,ket,N_bins):
        #selector_qobj = qt.tensor(qt.qeye(N_bins),qt.Qobj([[1,0],[0,1]])) # select only ground and excited states. Remove ph. states
        selector_qobj = qt.tensor(qt.qeye(N_bins),qt.Qobj([[1,0,0],[0,1,0],[0,0,0]])) # select only ground and excited states. Remove ph. states
        vel_ket = ((ket*selector_qobj).ptrace(0)).unit() # partial trace to get only velocity states
        oper_momentum = qt.num(N_bins,offset=-N_bins//2+1)
       
        mean = (oper_momentum*vel_ket).tr()
        return mean
        """
        DM_vel = DM.ptrace(0).unit() # partial trace to get DM over velocity space
        oper_momentum = qt.num(N_bins,offset=-N_bins//2+1)
        mean = (oper_momentum*DM_vel).tr()
        return mean
        """
    
    """
    Expected/theoretical standard deviation
    """
    def expect_std_theoretical(self,initial_state,N_bins,momentum_bins):
        selector_qobj = qt.tensor(qt.qeye(N_bins),qt.Qobj([[1,0,0],[0,1,0],[0,0,0]])) # select only ground and excited states. Remove ph. states
        #selector_qobj = qt.tensor(qt.qeye(N_bins),qt.Qobj([[1,0],[0,1]])) # select only ground and excited states. Remove ph. states
        vel_ket = ((selector_qobj.dag()*initial_state*selector_qobj).ptrace(0)).unit() # partial trace to get only velocity states
        oper_momentum = qt.num(N_bins,offset=-N_bins//2+1)
       
        n0 = np.sqrt((oper_momentum**2*vel_ket).tr()- (oper_momentum*vel_ket).tr()**2)
        
        
        select_negative = qt.qdiags(np.where(momentum_bins <= 0,1,0),offsets=0)
        select_negative2 = qt.qdiags(np.where(momentum_bins < 0,1,0),offsets=0)
        select_positive = qt.qdiags(np.where(momentum_bins > 0,1,0),offsets=0)
        N_m =  (oper_momentum*(select_positive*vel_ket)).tr()+ (-oper_momentum*(select_negative2*vel_ket)).tr()  + (select_negative*vel_ket).tr()
        N_ms = 2*(-oper_momentum*(select_negative2*vel_ket)).tr() + (select_negative*vel_ket).tr()

        #print("{} \n {} \n {}".format(n0,N_m,N_ms))

        N_arr = np.arange(np.floor(N_m))
        std = np.sqrt(n0**2 + N_arr**2 - 2*N_arr*N_m + N_ms)
        return(std)
    
    """
    Calculate energy via the energy density. Assume that the transverse beam is Gaussian with a width given by transverse_width
    """
    def calculate_pulse_energy(self,envelope_z, dt,transverse_width):
        integral_z = np.sum(envelope_z**2*dt) # perhaps I need to multiply by dt?
        print(integral_z)
        integral_r = np.sqrt(np.pi/2)*transverse_width**3/16 # analytical expression of integral with a Gausian distribution for transverse Efield
        print(integral_r)
        U = np.pi*eps0*hbar_eV**2/Debye**2*integral_z*integral_r # gives energy in eV
        return U*1.6e-19 # converts to J



class Ps_system(HamiltonianClass):
    def __init__(self,N_atoms=1,N_points=150,std_deviation_hbark=32,T=300):
        # TODO: change the definition of the cloud such that we initialise with a standard deviation rather than temperature
        self.T = T #K temperature of cloud
        self.m = 2*511e3 # eV/c^2
        self.beta =  1/(k*self.T)
        #self.std_deviation_hbark = std_deviation_hbark # std deviation in units of hbar k
        
        #self.std_deviation = self.std_deviation_hbark*hbar_eV*c/omega0/(self.m/c**2) #standard deviation of gaussian in cm/ps
        #print(self.std_deviation)
        self.std_deviation = np.sqrt((k*self.T/(self.m/c**2))) #standard deviation of gaussian in cm/ps
        
        self.amplitude = np.sqrt((self.m/c**2)/(2*np.pi*k*self.T))
        self.N_atoms = N_atoms
        
        self.momentum_bins = np.arange(-N_points,N_points+1)
        self.N_points = self.momentum_bins.size
        self.dv = 1.5e-7 # cm/ps, calculated such that 1 step is the equivalent of 1 unit of photon momentum for Ps        
        self.velocity_bins = self.dv*self.momentum_bins
        self.initial_pop = np.zeros(self.N_points)
    
        self.dp = 173 # eV ps/cm, 1 unit of momentum transfer with wavelength 247e-9nm onto Ps
        self.real_momentum_bins = self.dp*self.momentum_bins #eV ps/cm 
        self.max_vel = self.dv*self.N_points//2
        self.max_detuning = self.max_vel/c*omega0 /(2*np.pi) * 1e3 # GHz
        self.detuning_bins = np.linspace(-self.max_detuning,self.max_detuning,self.N_points)
        
        self.rate_SE = 1/142e3 # THz

        # Default values. Safe to override outside of class definition
        self.flag_SE_simple = False
        self.flag_SE_distributive = False
        self.flag_annihilation = False
        self.flag_photoionisation = False

        self.kets_vel = [qt.basis(self.N_points,n) for n in range(self.N_points)]
        
        # self.c_ops = []
        # self.e_ops = []
        # self.H = []
        #self.saved_states =[]
        #self.saved_expect = []

        
        
        #self.expect = dict()
    
    """
    Returns momentum operator for system
    """
    def e_momemtum(self):
        op = qt.ket2dm(self.real_momentum_bins)
        return op
    

    def init_distribution_singular(self, n=0):
        self.initial_pop[self.N_points//2 + n] = 1
        self.DM_vel = qt.qdiags(self.initial_pop,offsets=0)
    
    def init_distribution_flattop(self):
        self.DM_vel = qt.qeye(self.N_points)
        
        
    
    # Assume Maxwell-Boltzmann distribution
    def init_distribution_MB(self,v0=0,std_deviation=None):
        if std_deviation == None:
            std_deviation = self.std_deviation
        # for i in range(self.N_points-1):
        #     #self.initial_pop[i] = sp.integrate.quad(lambda v: self.amplitude*np.exp(-(v-v0)**2/(2*std_deviation**2))*self.N_atoms,self.velocity_bins[i],self.velocity_bins[i+1])[0]    
        #     self.initial_pop[i] = sp.integrate.quad(lambda v: np.exp(-(v-v0)**2/(2*std_deviation**2)),self.velocity_bins[i],self.velocity_bins[i+1])[0]    

        V_op = qt.qdiags(self.velocity_bins,offsets=0)
        #print(-V_op**2/(2*std_deviation**2))
        #print(std_deviation)
        self.DM_vel = (-0.5*(V_op/std_deviation)**2).expm()/((-0.5*(V_op/std_deviation)**2).expm().tr())

    # instantiate a new object with name given by label
    def init_pulse(self,pulse_kwargs):
        laserLabel = pulse_kwargs["label"]
        laserObj = laser(pulse_kwargs)
        self.laserDict[laserLabel] = laserObj
    
    
    # Initialise states in ground
    def init_states_ground(self,ret=False):
        basis_1S = qt.ket2dm(qt.basis(self.internal_dims,0))
        self.states = qt.tensor(self.DM_vel,basis_1S)# density matrix, composite of g/e space and vel space

        if ret == True:
            return self.states


    # Initialise states in excited
    def init_states_excited(self,ret=False):
        basis_2P = qt.ket2dm(qt.basis(self.internal_dims,1))
        self.states = qt.tensor(self.DM_vel,basis_2P) # density matrix, composite of g/e space and vel space
        
        if ret == True:
            return self.states


    # Initialise desymmetrized states
    def init_states_desymmetrized(self,ret=False):
        basis_1S = qt.ket2dm(qt.basis(self.internal_dims,0))
        basis_2P = qt.ket2dm(qt.basis(self.internal_dims,1) )
        
        #selector_ground = qt.qdiags(np.where(self.momentum_bins <= 0, 1, 0),offsets=0)
        #selector_excited = qt.qdiags(np.where(self.momentum_bins > 0, 1, 0),offsets=0)
        desymm_excited = qt.Qobj(np.sum(np.asarray([self.kets_vel[n-1]*self.kets_vel[n].dag() for n in range(self.N_points//2,self.N_points-1)]),axis=0))
        desymm_ground = qt.Qobj(np.sum(np.asarray([self.kets_vel[n]*self.kets_vel[n].dag() for n in range(0,self.N_points//2+1)]),axis=0))
        self.states = (qt.tensor(desymm_excited.dag()*self.DM_vel*desymm_excited,basis_2P)+qt.tensor(desymm_ground.dag()*self.DM_vel*desymm_ground,basis_1S)).unit()
        
        if ret == True:
            return self.states   

    
    def organise_result(self,result):
        # the class object keeps track of where the populations of each internal dimension is indexed in result.expect
        # for each internal dimension, make a new dictionary entry with label corresponding to internal dimension and 
        self.expect = dict()
        for label in self.idx_e_ops:         
            idx_range = self.idx_e_ops[label]

            # check to see if dict already has an entry with keyword given by label
            # if yes, append a new array to the existing value
            # each new iteration is then a new pulse
            if label in self.expect: 
                self.expect[label] = np.append(self.expect[label],[np.asarray(result.expect)[idx_range,-1]],axis=0)    
            else:
                self.expect[label] = [np.asarray(result.expect)[idx_range,0],np.asarray(result.expect)[idx_range,-1]]
            

    # interpret this DM as if it were a DM of this exact system, with the same e_ops and c_ops
    # def interpret_state(self,DM):       
    #     expect = dict()
    #     for label in self.idx_e_ops:
    #         idx_range = self.idx_e_ops[label]
    #         #print(idx_range)
    #         for n in idx_range:
    #             if label in expect:
    #                 expect[label].append((self.e_ops[n]*DM).tr() )
    #             else:
    #                 expect[label] = [(self.e_ops[n]*DM).tr()]
                
    #     return expect
    
    # legacy
    def evolve(self,save_path=None):
        self.laserDict = sorted(self.laserDict.items(),key=lambda x:x[1].order)
        opts = qt.Options(store_states=True)
        self.saved_states.append(self.states)
        for i in range(len(self.laserDict)):
            laser = self.laserDict[i][1]
            args = {"chirp":np.asarray(laser.chirp(laser.tlist,None)),
                    "wavevector":laser.direction,
                    "rabi":np.asarray(laser.rabi(laser.tlist,None)),
                    "beating":np.asarray(laser.rabi_beating2(laser.tlist,None)),
                    "selector1":laser.selector1,
                    "selector2":laser.selector2,
                    "tlist":laser.tlist,
                    "omega_L0":laser.omega_L0}
            
            self.create_composite(laser)
            self.set_Hamiltonian_MT(args)
            #print("direction of "+laser.label+": "+str(laser.direction))
            print("Simulating pulse number "+str(laser.order)+" ....")
            result = qt.mesolve(self.H, self.states,laser.tlist, e_ops=self.e_ops,c_ops=self.c_ops, options = opts)
            print("Done!")
            self.organise_result_expect(result)
            if save_path == None:
                self.saved_states.append(result.states[-1])
                self.states = result.states[-1]
            else:
                new_path = save_path +laser.label+".csv"
                self.states = result.states[-1]
                qt.qsave(self.states,new_path)
