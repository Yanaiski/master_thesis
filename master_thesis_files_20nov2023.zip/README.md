﻿# Simulations for master thesis 2022-2023
The most updated simulations are in 04_cmt_tensor.ipynb
